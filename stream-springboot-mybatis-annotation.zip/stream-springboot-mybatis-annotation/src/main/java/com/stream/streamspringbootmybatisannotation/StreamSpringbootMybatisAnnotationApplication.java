package com.stream.streamspringbootmybatisannotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMybatisAnnotationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMybatisAnnotationApplication.class, args);
	}
}
