package com.stream.streamspringbootmybatisxmlmulidatasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMybatisXmlMulidatasourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMybatisXmlMulidatasourceApplication.class, args);
	}
}
