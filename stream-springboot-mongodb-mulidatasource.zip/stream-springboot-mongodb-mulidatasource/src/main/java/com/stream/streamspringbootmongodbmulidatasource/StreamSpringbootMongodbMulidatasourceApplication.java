package com.stream.streamspringbootmongodbmulidatasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMongodbMulidatasourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMongodbMulidatasourceApplication.class, args);
	}
}
