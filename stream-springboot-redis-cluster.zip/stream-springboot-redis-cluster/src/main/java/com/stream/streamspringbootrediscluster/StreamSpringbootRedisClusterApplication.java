package com.stream.streamspringbootrediscluster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootRedisClusterApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootRedisClusterApplication.class, args);
	}
}
