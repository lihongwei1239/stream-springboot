package com.stream.streamspringbootrediscluster;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StreamSpringbootRedisClusterApplicationTests {

	@Test
	public void contextLoads() {
	}

}
