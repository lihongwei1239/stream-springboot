package com.stream.streamspringbootmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMailApplication.class, args);
	}
}
