package com.stream.streamspringbootmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMongodbApplication.class, args);
	}
}
