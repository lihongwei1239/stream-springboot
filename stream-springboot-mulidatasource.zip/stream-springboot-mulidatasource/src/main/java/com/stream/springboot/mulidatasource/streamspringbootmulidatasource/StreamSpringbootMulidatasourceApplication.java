package com.stream.springboot.mulidatasource.streamspringbootmulidatasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMulidatasourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMulidatasourceApplication.class, args);
	}
}
