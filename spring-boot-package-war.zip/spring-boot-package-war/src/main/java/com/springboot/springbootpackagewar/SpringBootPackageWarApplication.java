package com.springboot.springbootpackagewar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPackageWarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPackageWarApplication.class, args);
	}
}
