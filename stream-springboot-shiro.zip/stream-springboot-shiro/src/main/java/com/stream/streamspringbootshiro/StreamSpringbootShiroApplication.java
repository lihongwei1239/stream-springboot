package com.stream.streamspringbootshiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootShiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootShiroApplication.class, args);
	}
}
