package com.stream.streamspringbootmybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootMybatisApplication.class, args);
	}
}
