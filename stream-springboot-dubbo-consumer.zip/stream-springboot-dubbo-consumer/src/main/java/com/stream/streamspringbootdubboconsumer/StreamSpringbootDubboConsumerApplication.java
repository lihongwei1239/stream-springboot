package com.stream.streamspringbootdubboconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootDubboConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootDubboConsumerApplication.class, args);
	}
}
