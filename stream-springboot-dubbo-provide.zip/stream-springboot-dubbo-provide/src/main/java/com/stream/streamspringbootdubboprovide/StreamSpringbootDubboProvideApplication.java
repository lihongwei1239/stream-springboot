package com.stream.streamspringbootdubboprovide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamSpringbootDubboProvideApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamSpringbootDubboProvideApplication.class, args);
	}
}
